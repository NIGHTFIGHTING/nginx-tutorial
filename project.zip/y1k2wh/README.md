# nginx_imooc
云平台基于nginx中间件架构
