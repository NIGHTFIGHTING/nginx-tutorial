wget https://github.com/agentzh/lua-resty-memcached/archive/v0.11.tar.gz
tar -zxvf v0.11.tar.gz 
cp -r lua-resty-memcached-0.11/lib/resty /usr/local/share/lua/5.1/

